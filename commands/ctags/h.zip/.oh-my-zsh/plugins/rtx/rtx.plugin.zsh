# TODO: 2024-01-03 remove rtx support
echo "[oh-my-zsh] 'rtx' plugin has been renamed to 'mise'"
